
var background = document.getElementById("");
const quadradoRojo = document.querySelector("#objetivo");


var encendido = false; 
var enciertos = 0; cont = 0;

let intervalID;

let intervalTime;

var pulsados= 0;
var btnInicio = false;

var bntStart=0;
var finalP=false;

var interval = 4000;
// var now = new Date();

var timeTarget = 1*60*1000;


f__countdowns=null


function play(){
    console.log("play");

    
    

    if(!finalP){
        cambiarQuadrado();
        pararProceso();
    }
    

    

    if(pulsados >=1 && !finalP){
        interval =interval - 250;
    }
    
        
    if(!(pulsados >=1)){

        if(!finalP){
            // aquestes variables marquen el temps inicial de cronometre.
            var _seconds = 3*1000;
            var _minuts = 1*1000*60;
            // var _hours = 0*1000*60*60;
            var milisegundos = _seconds + _minuts ;
            
            f__countdowns = new Date(new Date().getTime() + milisegundos);
            
            intervalTime = setInterval(temporizador, 1);
        }
        
    }
    
        
    
    if(!finalP)
        cambiarPosicion();
        // console.log("🚀 ~ file: Juego.js ~ line 67 ~ play ~ finalP", finalP)


}


function temporizador() {

    var m , s , mls, mls2; // variables para establecer los ceros 
    
    var crono = document.querySelector("#minSec"); 
    var miliseconds = document.querySelector(".miliseconds");

    
    var fecha_actual = new Date();
    var milisecond = f__countdowns - fecha_actual;

    var segundosAc = Math.floor(milisecond/1000);

    var seconds = segundosAc % 60;
    var minutes = Math.floor((segundosAc / 60) % 60);
    

    if(minutes<10)  m="0"; else m=""; // es colocaran els ceros en el moment
    if(seconds<10)  s="0"; else s="";
    if(milisecond<10) mls="0"; else mls="";
    if(milisecond<100)  mls2="0"; else mls2="";


    var miliS = mls2+mls+(milisecond%1000);



    miliseconds.textContent = miliS;


    crono.textContent = m+minutes+":"+s+seconds;

    aviso(segundosAc);

    if(segundosAc<1){
        console.log("FIN tempo")

        pararProceso();
        pararTiempo();

        finalP = true;

        

        miliseconds.textContent = "000";
    }

}


function aviso(segundosAc){

    if(segundosAc<=10){
        console.log("🚀 ~ file: Juego.js ~ line 123 ~ aviso ~ segundosAc", segundosAc)
        document.querySelector(".msg").style.display = "flex";
    }else{
        document.querySelector(".msg").style.display = "none";
    }


}



function cambiarPosicion(){

    if(!intervalID) {
        intervalID = setInterval(cambiarQuadrado, interval);  
    }
}



function cambiarQuadrado(){
    

    // console.log(quadradoRojo);

    
    let ejeY=Math.floor(Math.random() * 450);
    let ejeX=Math.floor(Math.random() * 750);

    quadradoRojo.style.position = "relative";
    quadradoRojo.style.top = ejeY+"px";
    quadradoRojo.style.left = ejeX+"px";



}

function pararProceso(){
    console.log("stop");
    
    
    clearInterval(intervalID);
    intervalID=null;
}

function pararTiempo(){
    clearInterval(intervalTime);
    intervalTime = null;

    quadradoRojo.disabled="false";
    quadradoRojo.style.opacity = 1;
}



function pulsaciones() {
    if(!finalP){
        pulsados++;
        let marcador = document.getElementById("marcador");
        marcador.textContent = pulsados;
    }
    


}
